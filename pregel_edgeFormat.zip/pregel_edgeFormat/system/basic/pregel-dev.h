#ifndef PREGEL_DEV_H_
#define PREGEL_DEV_H_

#include <iostream>
#include "../utils/global.h"
#include "Vertex.h"
#include "Worker.h"
using namespace std;

#endif /* PREGEL_DEV_H_ */
